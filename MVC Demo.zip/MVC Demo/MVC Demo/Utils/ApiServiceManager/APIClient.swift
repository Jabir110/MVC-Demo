//
//  ApiClient.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation
import Alamofire

let ApiClient = APIClient.shared

class APIClient: NSObject
{
    // MARK: - SHARED MANAGER
    static let shared = APIClient()
    
    enum SPAPIResponseCode:Int {
        case SUCCESS = 200
        case CREATED_SUCCESS = 201
        case BAD_REQUEST = 400
        case MISSING_ACCESS_TOKEN = 401
        case EXPIRED_ACCESS_TOKEN = 402
        case INVALID_ACCESS_TOKEN = 403
        case USER_BLOCK = 423
    }
    
    //MARK:- COMMON POST METHOD
    private func callGETApiWithNetCheck(url : String, headersRequired : Bool, params : [String : Any]?,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void)
    {
        callGET_POSTApiWithNetCheck(isGet: true, url: url, headersRequired: headersRequired, params: params,isLoader:isLoader, completionHandler: completionHandler)
    }
    
    private func callPOSTApiWithNetCheck(url : String, headersRequired : Bool, params : [String : Any]?,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void){
        callGET_POSTApiWithNetCheck(isGet: false, url: url, headersRequired: headersRequired, params: params,isLoader:isLoader, completionHandler: completionHandler)
    }
    
    private func callRequestHeaders(headersRequired : Bool) -> ([String:String]) {
        
        var headers:[String:String] = [:]
        if headersRequired {
            headers[HeaderKeys.contentType] = "application/json"
            headers[HeaderKeys.Accept] = "application/json"
        }
        return (headers)
    }
    
    
    private func callGET_POSTApiWithNetCheck(isGet:Bool, url : String, headersRequired : Bool, params : [String : Any]? = nil,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void){
        
        if !ReachabilityManager.shared.isInternetAvailableForAllNetworks() {
            hideLoader()
            AlertInternetNotAvailable()
            return
        }
        
        if isLoader {
            showLoader()
        }
        
        let headers = self.callRequestHeaders(headersRequired: headersRequired)
        
        //print("/****************** NEW API CALLED ******************/")
        //print("/* API URL : \(url)")
        //print("/* API Params : \(String(describing: params))")
        //print("/* API Headers : \(headers)")
        //print("/*******************************************************/")
 
        Alamofire.request(url, method: isGet ? .get : .post, parameters: params, encoding: URLEncoding.default, headers: headers).responseJSON { (response) in
            
            if isLoader {
                hideLoader()
            }
                        
            switch response.result {
                
            case .success(let JSON):
                
                //print("JSON Response: \(JSON)")
                
                if let dictJson = JSON as? NSDictionary {
                    
                    let message = ""
                    guard let statusCode = response.response?.statusCode else {
                        completionHandler(message,dictJson,false)
                        return
                    }
                    
                    switch SPAPIResponseCode.init(rawValue: statusCode)! {
                        
                    case .CREATED_SUCCESS:
                        completionHandler(message,nil,true)
                    case .SUCCESS:
                        completionHandler(message,dictJson,true)
                    case .BAD_REQUEST:
                        completionHandler(message,nil,false)
                    case .MISSING_ACCESS_TOKEN:
                        completionHandler(message,nil,false)
                        break
                    case .EXPIRED_ACCESS_TOKEN:
                        completionHandler(message,nil,false)
                        break
                    case .INVALID_ACCESS_TOKEN:
                        completionHandler(message,nil,false)
                        break
                    case .USER_BLOCK:
                        completionHandler(message,nil,false)
                        break
                    }
                }
                else {
                    let error : String = (response.result.error?.localizedDescription)! as String
                    completionHandler(error,nil,false)
                }
                
            case .failure( _):
                
                let error : String = (response.result.error?.localizedDescription)! as String
                completionHandler(error,nil,false)
            }
        }
    }
    
    private func callUPLOADApiWithNetCheck(url : String,requestMethod:HTTPMethod = .post, document:[AnyObject]?, headersRequired : Bool, params : [String : Any]?,uploadKey:EnumUploadImagesType = .documentsKey,isLoader:Bool, completionHandler : @escaping (String?,NSDictionary?,Bool) -> Void){
        
        if !ReachabilityManager.shared.isInternetAvailableForAllNetworks(){
            AlertInternetNotAvailable()
            completionHandler(nil,nil,false)
            return
        }
        
        if isLoader {
            showLoader()
        }
        
        let headers = self.callRequestHeaders(headersRequired: headersRequired)
        
        //print("/****************** NEW API CALLED ******************/")
        //print("/* API URL : \(url)")
        //print("/* API Params : \(String(describing: params))")
        //print("/* API Headers : \(headers)")
        //print("/*******************************************************/")
        
        Alamofire.upload(multipartFormData:{ multipartFormData in
            
            if let params = params
            {
                for eachKey in params.keys
                {
                    print("UPLOAD KEYS:\(eachKey) : \(String(describing: params[eachKey]))")
                    
                    if let value = params[eachKey] as? String
                    {
                        multipartFormData.append(value.data(using: .utf8)!, withName: eachKey)
                    }
                    else  if let arrayString = params[eachKey] as? [String]
                    {
                        if let jsonArr = try? JSONEncoder().encode(arrayString)
                        {
                            multipartFormData.append(jsonArr, withName: eachKey)
                        }
                        
                        //    multipartFormData.append(getStringFromDictionary(dict: arrayString).data(using: .utf8)!, withName: eachKey)
                        
                    }else if let value = params[eachKey]
                    {
                        let strValue = "\(value)"
                        
                        multipartFormData.append(strValue.data(using: .utf8)!, withName: eachKey)
                    }
                }
            }
            
            if document != nil
            {
                for object in document!
                {
                    if let imgObject = object as? FileMedia {
                        if let mbData = imgObject.image!.compressData(maxFileSize: 10) {
                            multipartFormData.append(mbData, withName: uploadKey.key , fileName: "\(randomStringGenerate()).\(Data.fileExtension(for: mbData))" , mimeType: Data.mimeType(for: mbData))
                        }
                    }
                }
            }
        },
                         usingThreshold:UInt64.init(),
                         to:url,
                         method:requestMethod,
                         headers:headers,
                         encodingCompletion: { encodingResult in
                            
                            if isLoader {
                                showLoader()
                            }
                            
                            switch encodingResult
                            {
                            case .success(let upload, _, _):
                                
                                upload.responseString(completionHandler: { (response) in
                                    print(response)
                                })
                                
                                upload.responseJSON { (response) in
                                    
                                    if isLoader {
                                        hideLoader()
                                    }
                                    
                                    switch response.result {
                                    case .success(let JSON):
                                        print("JSON Response: \(JSON)")
                                        if let dictJson = JSON as? NSDictionary {
                                            //let statusCode = dictJson.object_forKeyWithValidationForClass_Int(aKey: ResponseKeys.statusKey)
                                            let message = dictJson.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.messageKey)
                                            guard let statusCode = response.response?.statusCode else {
                                                completionHandler(message,dictJson,false)
                                                return
                                            }
                                            
                                            switch SPAPIResponseCode.init(rawValue: statusCode)! {
                                                
                                            case .CREATED_SUCCESS:
                                                completionHandler(message,dictJson,true)
                                            case .SUCCESS:
                                                completionHandler(message,dictJson,true)
                                            case .BAD_REQUEST:
                                                completionHandler(message,nil,false)
                                            case .MISSING_ACCESS_TOKEN:
                                                //LOGOUT
                                                break
                                            case .EXPIRED_ACCESS_TOKEN:
                                                // actule call api for access token refress
                                                // but right now we display message and redirect to login screen
                                                //self.logoutAlertAfterSessionExpired(message: message)
                                                break
                                            case .INVALID_ACCESS_TOKEN:
                                                // display message and redirect to login screen
                                                //self.logoutAlertAfterSessionExpired(message: message)
                                                break
                                            case .USER_BLOCK:
                                                // display message and redirect to login screen
                                                //self.logoutAlertAfterSessionExpired(message: message)
                                                break
                                            }
                                            
                                        }
                                        else {
                                            let error : String = (response.result.error?.localizedDescription)! as String
                                            completionHandler(error,nil,false)
                                        }
                                        
                                    case .failure( _):
                                        
                                        let error : String = (response.result.error?.localizedDescription)! as String
                                        
                                        completionHandler(error,nil,false)
                                    }
                                }
                                
                            case .failure(let encodingError):
                                print("ERR: UPLOAD: \(encodingError.localizedDescription)")
                                
                                let error : String = (encodingError.localizedDescription) as String
                                
                                completionHandler(error,nil,false)
                            }
        })
    }
    
    func cancellAllPendingRequests(){
        
        let sessionManager = Alamofire.SessionManager.default;
        
        sessionManager.session.getTasksWithCompletionHandler { dataTasks, uploadTasks, downloadTasks in
            
            print("\n\n")
            
            dataTasks.forEach({ (task) in
                print("1 id : \(task.taskIdentifier) __ \(String(describing: task.currentRequest)) __ \(String(describing: task.originalRequest))")
            })
            
            dataTasks.forEach({ (task) in
                print("2 id : \(task.taskIdentifier) __ \(String(describing: task.currentRequest)) __ \(String(describing: task.originalRequest))")
            })
            
            dataTasks.forEach({ (task) in
                print("3 id : \(task.taskIdentifier) __ \(String(describing: task.currentRequest)) __ \(String(describing: task.originalRequest))")
            })
            
            dataTasks.forEach { $0.cancel() }
            uploadTasks.forEach { $0.cancel() }
            downloadTasks.forEach { $0.cancel() }
        }
    }
}

// MARK:- USER MODULE
extension APIClient{
    
    //COMPANY LIST API
    func callCompanyListApi(params : [String : Any]? = nil,Completion completion:@escaping (_ isSuccess:Bool,_ response:[Company],_ message:String?) -> Void) {
        
        var arrCompany : [Company] = []

        self.callGET_POSTApiWithNetCheck(isGet: true, url: ApiURL.activesApiURL, headersRequired: true, params: params, isLoader: true) { (errorMessage, response, status) in
            
            if status {
                let arrList = response?.allKeys
                for list in arrList!{
                    arrCompany.append(Company.init(withDetails: response?.value(forKey: list as! String) as! NSDictionary))
                }
                //print("RESPONSE: \(arrCompany.count)")
            }
            completion(status,arrCompany,errorMessage)
        }
    }
    
    //INCOME DETAILS API
    func callIncomeDetailsApi(params : [String : Any]? = nil,Completion completion:@escaping (_ isSuccess:Bool,_ response:[IncomeDeatails],_ message:String?) -> Void) {
        
        var arrIncomeDeatails : [IncomeDeatails] = []

        let key:String = params!["Ticker"] as! String
        let strText:String = ApiURL.incomeDeatailsApiURL
        
        let newUrl = strText.replacingOccurrences(of: "{KEY}", with: key)

        self.callGET_POSTApiWithNetCheck(isGet: true, url: newUrl, headersRequired: true, params: params, isLoader: true) { (errorMessage, response, status) in
            
            if status {
                let objDic:NSDictionary = ((response!).value(forKey: key)) as! NSDictionary
                let arrList = objDic.allKeys
                for list in arrList{
                    arrIncomeDeatails.append(IncomeDeatails.init(withDetails: objDic.value(forKey: list as! String) as! NSDictionary, title: list as! String))
                }
                //print("RESPONSE: \(arrIncomeDeatails.count)")
            }
            completion(status,arrIncomeDeatails,errorMessage)
        }
    }
}
