//
//  HomeViewController.swift
//  Expense
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class IncomeDetailsViewController: UIViewController {

    //MARK:- OUTLET
    @IBOutlet private weak var incomeDeatailsCollectionView: IncomeDetailsCollectionView!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        self.callIncomeDetailsApiwith()
    }
    
    //MARK:- SETUP UI
    private func setupUI(){
        
        //NAVIGATION BAR
        self.title = "CollectionView"
        self.navigationController?.navigationBar.tintColor = UIColor.black
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage.init(named: "left_Arrow"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(btnBackActionHandler(_:)))

        //BLOCK REGISTER
        self.incomeDeatailsCollectionView.blockCollectionViewDidSelectAtIndexPath = { (objIncomeDetails) in
            print("TITLE: \(String(describing: objIncomeDetails.title!))")
        }
    }
    
    //MARK:- BUTTON ACTION
    @objc private func btnBackActionHandler(_ sender : AnyObject){
        self.popTo()
    }

}

//MARK:- APIS -
extension IncomeDetailsViewController {

    private func callIncomeDetailsApiwith() {
                        
        var params: [String : Any] = [:]
        params["Ticker"] = "GOOGL"

        ApiClient.callIncomeDetailsApi(params: params) { (status, response, message) in
            
            if status {
                self.incomeDeatailsCollectionView.arrIncomeDeatails = response
                self.incomeDeatailsCollectionView.reloadData()
            }
            else {
                print("Error: \(String(describing: message))")
            }
        }
    }
}
