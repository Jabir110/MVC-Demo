//
//  HomeViewController.swift
//  Expense
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class CompanyListViewController: UIViewController {

    //MARK:- OUTLET
    @IBOutlet private weak var companyListTableView: CompanyListTableView!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        self.callCompanyListApiwith()
    }
    
    //MARK:- SETUP UI
    private func setupUI(){
        
        //NAVIGATION BAR
        self.title = "TableView"
        self.navigationController?.navigationBar.tintColor = UIColor.black
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage.init(named: "left_Arrow"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(btnBackActionHandler(_:)))
        
        //BLOCK REGISTER
        self.companyListTableView.blockTableViewDidSelectAtIndexPath = { (objCompany) in
            print("COMPANY NAME: \(String(describing: objCompany.companyName!))")
        }
    }
    
    //MARK:- BUTTON ACTION
    @objc private func btnBackActionHandler(_ sender : AnyObject){
        self.popTo()
    }
}

//MARK:- APIS -
extension CompanyListViewController {

    private func callCompanyListApiwith() {
        
        ApiClient.callCompanyListApi(params: nil) { (status, response, message) in
            if status {
                self.companyListTableView.arrCompanyList = response
                self.companyListTableView.reloadData()
            }
            else {
                print("Error: \(String(describing: message))")
            }
        }
    }
}
