//
//  CompanyListCollectionViewCell.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class IncomeDetailsCollectionViewCell: CustomCollectionViewCell {

    //MARK:- OUTLET
    @IBOutlet private weak var lblTitle: CustomLabel!
    @IBOutlet private weak var lbl2015_12: CustomLabel!
    @IBOutlet private weak var lbl2016_12: CustomLabel!
    @IBOutlet private weak var lbl2017_12: CustomLabel!
    @IBOutlet private weak var lbl2018_12: CustomLabel!
    @IBOutlet private weak var viewMain: UIView!

    //MARK:- AWAKE FROM NIB
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
        // Initialization code
    }
    
    // MARK:- SETUP UI & DATA
    private func setupUI() {
        viewMain.layer.cornerRadius = 5.0
        viewMain.backgroundColor = UIColor.groupTableViewBackground
    }

    func updateDate(objIncomeDetails: IncomeDeatails) {
        lblTitle.text = objIncomeDetails.title
        lbl2015_12.text = objIncomeDetails.v2015
        lbl2016_12.text = objIncomeDetails.v2016
        lbl2017_12.text = objIncomeDetails.v2017
        lbl2018_12.text = objIncomeDetails.v2018
    }
}
