//
//  CompanyDeatails.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation
import UIKit

struct IncomeDeatailsModelKeys {
    static let k2014 = "2014-12"
    static let k2015 = "2015-12"
    static let k2016 = "2016-12"
    static let k2017 = "2017-12"
    static let k2018 = "2018-12"
    static let kTtm  = "TTM"
}

class IncomeDeatails: NSObject
{
    var title: String? = ""
    var v2014: String? = ""
    var v2015: String? = ""
    var v2016: String? = ""
    var v2017: String? = ""
    var v2018: String? = ""
    var vTtm: String? = ""

    override init() {
        super.init()
    }
    
    convenience init(withDetails dict: NSDictionary, title:String) {
        self.init()
        
        self.title = title
        self.v2014 = dict.object_forKeyWithValidationForClass_String(aKey: IncomeDeatailsModelKeys.k2014)
        self.v2015 = dict.object_forKeyWithValidationForClass_String(aKey: IncomeDeatailsModelKeys.k2015)
        self.v2016 = dict.object_forKeyWithValidationForClass_String(aKey: IncomeDeatailsModelKeys.k2016)
        self.v2017 = dict.object_forKeyWithValidationForClass_String(aKey: IncomeDeatailsModelKeys.k2017)
        self.v2018 = dict.object_forKeyWithValidationForClass_String(aKey: IncomeDeatailsModelKeys.k2018)
        self.vTtm = dict.object_forKeyWithValidationForClass_String(aKey: IncomeDeatailsModelKeys.kTtm)

    }
}
