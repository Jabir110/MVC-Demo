
//
//  CustomTextField.swift
//
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit
import PureLayout


public enum CustomTextFieldKeyboardType: Int{
    
    case None_NOSPACE
    case Characters
    case Characters_NOSPACE
    case Characters_Number
    case Characters_Number_NOSPACE
    case Characters_SplCharacters
    case Characters_SplCharacters_NOSPACE
    
    case Float
    
    case Phone
    case Number
    case Number_Nozero
    case Number_Space
    
    case Email
    case Password
    
    case Picker
    case DatePicker
    case none
}

public enum CustomTextFieldType: Int{
    
    case FloatingLabel
    case BottomLine
    case none
}

public enum TextFieldState: Int{
    case normal
    case edittable
}


open class CustomTextField: UITextField, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    // MARK:- Blocks
    
    /// Block for Picker Cancel button Click
    public var blockCallFor_CancelButtonClicked    : ((_ txtField:CustomTextField)->Void)?
    
    /// Block for Picker Done button Click
    public var blockCallFor_DoneButtonClicked      : ((_ txtField:CustomTextField)->Void)?
    
    /// Block for Picker value change event
    public var blockCallFor_PickerValueChanged     : ((_ txtField:CustomTextField)->(Void))?
    
    // Block for textfiled deleget
    public var blockTextFieldDidBeginEditing        : ((_ textField: CustomTextField) -> Void)?
    public var blockTextFieldDidEndEditing          : ((_ textField: CustomTextField) -> Void)?
    
    public var blockTextFieldShouldBeginEditing     : ((_ textField: CustomTextField) -> Void)?
    public var blockTextFieldShouldEndEditing       : ((_ textField: CustomTextField) -> Void)?
    
    public var blockTextFieldShouldReturn           : ((_ textField: CustomTextField) -> Void)?
    public var blockShouldChangeCharactersIn        : (( _ textField: CustomTextField,  _ newString: String) -> Void)?
    
    
    
    
    // MARK:- PROPERTIES
    // MARK:- Variable
    
    
    /// For Text PickerView
    public var pickerView:UIPickerView?
    
    /// For  Date PickerView
    public var datePicker: UIDatePicker?
    public var dateFormate : String?
    public var pickerMode : UIDatePicker.Mode = .date
    /// Selected picker value
    public var selectedPickerValue     : Any!
    
    
    /// Selected Date from PickerView
    public var selectedDateValue       : Date      = Date()
    
    /// Array for PickerView value type Any ["1","A",1]
    public var arrDataSource           : [Any]     = []
    
    
    /// Get click event of TextField
    public typealias Action = (UITextField) -> Void
    fileprivate var actionEditingChanged: Action?
    
    public var leftViewPadding              : CGFloat? = 0
    public var leftTextPadding              : CGFloat? = 0
    public var shouldPreventAllActions      : Bool = false
    public var canCut                       : Bool = true
    public var canCopy                      : Bool = true
    public var canPaste                     : Bool = true
    public var canSelect                    : Bool = true
    public var canSelectAll                 : Bool = true
    public var needToLayoutSubviews         : Bool = true
    
    
    /// For BottomLine TextField
    var viewBottomLine: UIView?
    public var constraintViewBottomLine:[NSLayoutConstraint]!
    
    /// Floating Label
    open var titleLabel: UILabel!
    
    
    /// Set textField state
    public var textFieldState : TextFieldState = .normal {
        didSet {
            self.updateTextFieldState()
        }
    }
    
    /// Set Textfield state
    override open var text: String?{
        didSet {
            self.updateTextFieldState()
        }
    }
    
    
    /// Config file for set all varible
    public var config : CustomTextField.Config = CustomTextField.Config() {
        didSet {
            self.update()
        }
    }
    
    public func update() {
        self.setUpTextFieldBasic()
    }
    
    public func setConfig(config : Config) {
        self.config = config
        self.setUpTextFieldBasic()
    }
    
    
    
    // MARK:- IBINSPECTABLE
    
    
    /// TextField tint color.
    public var tintcolor: UIColor {
        get {
            return self.tintColor!
        }
        set {
            self.tintColor = newValue
        }
    }
    
    
    
    /// TextField text color.
    public var textcolor: UIColor {
        get {
            return self.textColor!
        }
        set {
            self.textColor = newValue
        }
    }
    
    // MARK:-
    // MARK:- INIT
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.commonInit()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    override open func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    // Provides left padding for images
    override open func leftViewRect(forBounds bounds: CGRect) -> CGRect {
        var textRect = super.leftViewRect(forBounds: bounds)
        textRect.origin.x += leftViewPadding!
        return textRect
    }
    
    override open func textRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.insetBy(dx: (leftTextPadding!) + (leftView?.frame.size.width ?? 0) + (leftViewPadding!), dy: 0)
    }
    
    override open func editingRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.insetBy(dx: (leftTextPadding!) + (leftView?.frame.size.width ?? 0) + (leftViewPadding!), dy: 0)
    }
    
    override open func layoutSubviews() {
        super.layoutSubviews()
        
        if self.needToLayoutSubviews {
            self.needToLayoutSubviews = false
        }
    }
    
    override open func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        
        if(self.shouldPreventAllActions){
            return false
        }
        
        switch action {
        case #selector(UIResponderStandardEditActions.cut(_:)):
            return self.canCut ? super.canPerformAction(action, withSender: sender) : self.canCut
        case #selector(UIResponderStandardEditActions.copy(_:)):
            return self.canCopy ? super.canPerformAction(action, withSender: sender) : self.canCopy
        case #selector(UIResponderStandardEditActions.paste(_:)):
            return self.canPaste ? super.canPerformAction(action, withSender: sender) : self.canPaste
        case #selector(UIResponderStandardEditActions.select(_:)):
            return self.canSelect ? super.canPerformAction(action, withSender: sender) : self.canSelect
        case #selector(UIResponderStandardEditActions.selectAll(_:)):
            return self.canSelectAll ? super.canPerformAction(action, withSender: sender) : self.canSelectAll
        default:
            return super.canPerformAction(action, withSender: sender)
        }
    }
    
    
    // MARK:-
    
    
    /// Action edit changed
    ///
    /// - Parameter closure: your action.
    public func action(closure: @escaping Action) {
        if actionEditingChanged == nil {
            addTarget(self, action: #selector(CustomTextField.textFieldDidChange), for: .editingChanged)
        }
        actionEditingChanged = closure
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        actionEditingChanged?(self)
        updateFloationglabel(hasText)
    }
    
    
    /// Default property set methord.
    func commonInit(){
        
        //VALIDATIONS
        if (self.config.minLength == nil) {
            self.config.minLength = 0
        }
        if (self.config.maxLength == nil  || self.config.maxLength == 0) {
            self.config.maxLength = 256
        }
        
        self.textcolor = self.config.textColor!
        
        self.autocorrectionType = .no
        
        self.delegate = self
        
        if self.text?.count != 0 {
            self.self.updateFloationglabel(hasText)
        }
    }
    
    
    // MARK:- Comman Function
    
    public func setUpTextFieldValidation(minLength : NSInteger,
                                         maxLength : NSInteger,
                                         textFieldKeyboardType :CustomTextFieldKeyboardType,
                                         textFieldType :CustomTextFieldType) {
        
        self.config.maxLength               = maxLength
        self.config.minLength               = minLength
        self.config.textFieldType           = textFieldType
        self.config.textFieldKeyboardType  = textFieldKeyboardType
    }
    
    public func setUpBottomLineTextFieldColors(placeholderColor : UIColor,
                                               bottomLineNormalColor : UIColor,
                                               bottomLineEditingColor :UIColor) {
        
        self.config.placeholderColor           = placeholderColor
        self.config.bottomLineNormalColor      = bottomLineNormalColor
        self.config.bottomLineEditingColor     = bottomLineEditingColor
    }
    
    public func setUpFloatingLabelTextFieldColors(placeholderColor : UIColor,
                                                  floatingLabelEditingColor : UIColor,
                                                  bottomLineNormalColor : UIColor,
                                                  bottomLineEditingColor :UIColor) {
        
        self.config.placeholderColor           = placeholderColor
        self.config.floatingLabelEditingColor  = floatingLabelEditingColor
        self.config.bottomLineNormalColor      = bottomLineNormalColor
        self.config.bottomLineEditingColor     = bottomLineEditingColor
    }
    
    
    
    // MARK:- Textfield Deleget.
    
    open func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if self.checkMaxLength(range, maxLength: self.config.maxLength!, current: string) == false{
            let fullText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
            if self.blockShouldChangeCharactersIn != nil {
                self.blockShouldChangeCharactersIn?(textField as! CustomTextField, fullText)
            }
            return false
        }
        
        /*
        //Check Selected Lanuage
        if AILocalization.getCurruntDeviceLanguage() == .english
        {
            if let isSuccess : Bool = self.checkTextValidation(range, replacementString: string, txtType: self.config.textFieldKeyboardType) as Bool {
                let fullText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
                if self.blockShouldChangeCharactersIn != nil {
                    self.blockShouldChangeCharactersIn?(textField as! CustomTextField, fullText)
                }
                return isSuccess
            }
        }*/
        
        return true
        
        // return self.checkTextValidation(range, replacementString: string, txtType: self.config.textFieldKeyboardType)
    }
    
    open func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if self.blockTextFieldShouldBeginEditing != nil {
            self.blockTextFieldShouldBeginEditing?(textField as! CustomTextField)
        }
        
        return true
    }
    
    open func textFieldDidBeginEditing(_ textField: UITextField) {
        
        self.getAllTextField()
        
        switch self.config.textFieldKeyboardType {
        case .Picker:
            if let fooOffset = arrDataSource.index(where: {(($0 as AnyObject) as! String) == self.text!}) {
                // do something with fooOffset
                self.pickerView?.selectRow(fooOffset, inComponent: 0, animated: true)
            }
        default:
            break
        }
        
        
        // Change textField mode
        self.textFieldState = .edittable
        if self.blockTextFieldDidBeginEditing != nil {
            self.blockTextFieldDidBeginEditing?(textField as! CustomTextField)
        }
    }
    
    open func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        if self.blockTextFieldShouldEndEditing != nil {
            self.blockTextFieldShouldEndEditing?(textField as! CustomTextField)
        }
        
        return true
    }
    
    open func textFieldDidEndEditing(_ textField: UITextField) {
        
        // Change textField mode
        self.textFieldState = .normal
        
        // Trim Text
        self.trimText()
        
        if self.blockTextFieldDidEndEditing != nil {
            self.blockTextFieldDidEndEditing?(textField as! CustomTextField)
        }
    }
    
    open func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.resignFirstResponder()
        self.getNextTextField()
        
        if self.blockTextFieldShouldReturn != nil {
            self.blockTextFieldShouldReturn?(textField as! CustomTextField)
        }
        return true
    }
    
    func getNextTextField() {
        
        if self.tag != myViews.count{
            myViews[self.tag].becomeFirstResponder()
        }else{
            self.resignFirstResponder()
        }
        
    }
    
    var myViews : [UITextField]! = [UITextField]()
    func getAllTextField() {
        
        myViews.removeAll()
        
        let vc = self.parentViewController
        
        self.listSubviewsOfView(view: (vc?.view)!)
        
        for i in 0..<myViews.count{
            
            
            myViews[i].tag = i + 1
            myViews[i].returnKeyType = .next
            
            if i == myViews.count-1{
                myViews[i].returnKeyType = .done
            }
        }
    }
    func listSubviewsOfView(view:UIView){
        
        // Get the subviews of the view
        let subviews = view.subviews
        
        // Return if there are no subviews
        if subviews.count == 0 {
            return
        }
        
        let allA = (subviews.filter({ (view) -> Bool in
            if let tf = view as? UITextField{
                if tf.isHidden == true || tf.isEnabled == false{
                    return false
                }else{
                    return  true
                }
            }
            return false
            
        }))
        
        myViews.append(contentsOf: allA as! [UITextField])
        
        for subview : AnyObject in subviews{
            // List the subviews of subview
            listSubviewsOfView(view: subview as! UIView)
        }
    }
    
    //    func getNextTextField() {
    //
    //        let vc = self.parentViewController
    //        //let myViews = self.superview?.subviews.filter{$0 is UITextField}
    //
    //        self.listSubviewsOfView(view: (vc?.view)!)
    //
    //    }
    
    //    func listSubviewsOfView(view:UIView){
    //
    //        // Get the subviews of the view
    //        let subviews = view.subviews
    //
    //        // Return if there are no subviews
    //        if subviews.count == 0 {
    //            return
    //        }
    //        let myViews = subviews.filter{$0 is UITextField}
    //
    //        for subview : AnyObject in subviews{
    //
    //            // Do what you want to do with the subview
    //            print(subview)
    //
    //
    //            // List the subviews of subview
    //            listSubviewsOfView(view: subview as! UIView)
    //        }
    //    }
    
    
    //    open override func resignFirstResponder() -> Bool {
    //        return true
    //    }
    
    
    // MARK:- setUp TextFieldType
    fileprivate func setUpTextFieldType() {
        
        switch self.config.textFieldType {
        case .BottomLine:
            if self.viewBottomLine == nil {
                
                // Add Bottom line.
                self.createBottomLineView()
                self.borderStyle = .none
                // Check Textfield State.
                self.updateTextFieldState()
            }
            
        case .FloatingLabel:
            if self.viewBottomLine == nil {
                
                // Add Bottom line.
                self.createBottomLineView()
                self.borderStyle = .none
                // Check Textfield State.
                self.updateTextFieldState()
            }
            self.createTitleLabel()
            addTarget(self, action: #selector(CustomTextField.textFieldDidChange), for: .editingChanged)
            
        default: break
            
        }
        
    }
    
    
    /// Creaet Bottom line.
    fileprivate func createBottomLineView() {
        let viewLine = UIView()
        viewLine.backgroundColor = UIColor.red
        self.addSubview(viewLine)
        
        //adding Contraints to Bottomview
        constraintViewBottomLine = viewLine.autoPinEdgesToSuperviewEdges(with: UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 00), excludingEdge: .top)
        //viewLine.autoPinEdgesToSuperviewEdges(with: UIEdgeInsetsMake(0, 0, 0, 0), excludingEdge: .top)
        viewLine.autoSetDimension(.height, toSize: 0.5)
        self.viewBottomLine = viewLine
    }
    
    /// Create Floating label.
    fileprivate func createTitleLabel() {
        if titleLabel == nil {
            let titleLabel = UILabel()
            titleLabel.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            titleLabel.font = UIFont.init(name: (self.font?.familyName)!, size: 13.0) // .systemFont(ofSize: 13)
            titleLabel.alpha = 1.0
            titleLabel.textColor = self.config.placeholderColor
            titleLabel.text = self.placeholder
//            titleLabel.backgroundColor = UIColor.red
            addSubview(titleLabel)
            self.titleLabel = titleLabel
            
            let frame: CGRect = titleLabelRectForBounds(bounds, editing: (self.text?.count == 0 ? false : true))
            print("X-POS: \(frame.origin.x)")
            self.titleLabel.frame = frame
            self.updateFloationglabel(false)
        }
    }
    
    
    /// Calcualte title font Height.
    ///
    /// - Returns: CGFloat
    open func titleHeight() -> CGFloat {
        if let titleLabel = titleLabel,
            let font = titleLabel.font {
            return font.lineHeight
        }
        return 15.0
    }
    
    /// Set Floating label frame.
    ///
    /// - Parameters:
    ///   - bounds: pass rect (CGRect)
    ///   - editing: is Editing mode (Bool)
    /// - Returns: new rect
    open func titleLabelRectForBounds(_ bounds: CGRect, editing: Bool) -> CGRect {
        if editing {
            
            return  CGRect(x: self.editingRect(forBounds: self.bounds).origin.x , y: self.frame.height/2 - (titleHeight() * 1.75) , width: bounds.size.width, height: titleHeight())
            
            //  return  CGRect(x: self.leftView !=  nil ? (self.leftView?.frame.width)! + self.editingRect(forBounds: self.bounds).origin.x : (self.editingRect(forBounds: self.bounds).origin.x) , y: self.frame.height/2 - (titleHeight() * 1.75) , width: bounds.size.width, height: titleHeight())
            
            //    return  CGRect(x: self.leftView !=  nil ? (self.leftView?.frame.width)! + leftTextPadding! : (leftTextPadding)! , y: 0 - (titleHeight()/2)  , width: bounds.size.width, height: titleHeight())
        }
        return CGRect(x: self.editingRect(forBounds: self.bounds).origin.x , y: self.frame.height/2 - (titleHeight()/2), width: bounds.size.width, height: titleHeight())
        // return CGRect(x: self.leftView !=  nil ? (self.leftView?.frame.width)! + leftTextPadding! : (leftTextPadding)! , y: self.frame.height/2 - (titleHeight()/2), width: bounds.size.width, height: titleHeight())
    }
    
    
    private func setUpTextFieldBasic() {
        
        // When updating textfield state (editing mode , normale mode)
        
        
        self.textcolor = self.config.textColor!
        
        
        
        self.updateTextFieldKeyboardType()
        self.setUpTextFieldType()
        
        
        if self.config.textFieldType == .BottomLine {
            if self.textFieldState == .normal {
                self.viewBottomLine?.backgroundColor = config.bottomLineNormalColor
            }
            else {
                self.viewBottomLine?.backgroundColor = config.bottomLineEditingColor
            }
        }
        else if self.config.textFieldType == .FloatingLabel {
            if self.textFieldState == .normal {
                self.viewBottomLine?.backgroundColor = config.bottomLineNormalColor
            }
            else {
                self.viewBottomLine?.backgroundColor = config.bottomLineEditingColor
            }
        }
        
        if self.textFieldState == .normal {
            self.setPlaceHolderTextColor(self.config.placeholderColor!)
            //  self.titleLabel.textColor = self.config.placeholderColor!
        }
        else {
            self.setPlaceHolderTextColor(self.config.floatingLabelEditingColor!)
            // self.titleLabel.textColor = self.config.floatingLabelEditingColor!
        }
        
        self.updateFloationglabel(hasText)
    
    }
    
    /// Update textfield bottom line color when change editing mode.
    private func updateTextFieldState() {
        
        // When updating textfield state (editing mode , normale mode)
        
        if self.config.textFieldType == .BottomLine {
            if self.textFieldState == .normal {
                self.viewBottomLine?.backgroundColor = config.bottomLineNormalColor
            }
            else {
                self.viewBottomLine?.backgroundColor = config.bottomLineEditingColor
            }
        }
        else{
            if self.textFieldState == .normal {
                self.viewBottomLine?.backgroundColor = config.bottomLineNormalColor
            }
            else {
                self.viewBottomLine?.backgroundColor = config.bottomLineEditingColor
            }
        }
        self.updateFloationglabel(hasText)
    }
    
    
    /// Animatiing and hide show floatiog label.
    ///
    /// - Parameter editing: Bool
    fileprivate func updateFloationglabel(_ editing : Bool = false) {
        
        
        
        
        let titleFadeInDuration: TimeInterval = 0.2     /// The value of the title appearing duration
        let titleFadeOutDuration: TimeInterval = 0.3    /// The value of the title disappearing duration
        let alpha: CGFloat = editing ? 1.0 : 0.0
        let frame: CGRect = titleLabelRectForBounds(bounds, editing: editing)
        let updateBlock = { () -> Void in
            if self.titleLabel != nil{
                self.titleLabel.alpha = alpha
                self.titleLabel.frame = frame
                
                
                
                if self.textFieldState == .normal {
                    self.titleLabel.textColor = self.config.placeholderColor!
                }
                else {
                    self.titleLabel.textColor = self.config.floatingLabelEditingColor!
                }
                
            }
        }
        
        let animationOptions: UIView.AnimationOptions = .curveEaseOut
        let duration = editing ? titleFadeInDuration : titleFadeOutDuration
        
        UIView.animate(withDuration: duration, delay: 0, options: animationOptions, animations: {
            updateBlock()
        }) { (isFinish) in
            
        }
        
        self.layoutIfNeeded()
        
    }
    
    // MARK:- updateTextFieldKeyboardType
    fileprivate func updateTextFieldKeyboardType() {
        self.leftViewMode = .always
        
        switch self.config.textFieldKeyboardType {
            
        case .Picker:
            self.autocorrectionType = .no
            self.autocapitalizationType = .none
            self.shouldPreventAllActions = false
            self.setUpInputViewForPicker(arr: [])
            self.pickerView?.delegate = self
            self.pickerView?.dataSource = self
            // self.pickerView?.selectRow(selectedPickerIndex, inComponent: 0, animated: true)
            
            if let fooOffset = arrDataSource.index(where: {($0 as AnyObject).name == self.text}) {
                // do something with fooOffset
                print(fooOffset)
            }
            
            //            if let found = find(lazy(arrDataSource).map({ $0.name }), self.text) {
            //                let obj = arrDataSource[found]
            //            }
            
            
            break
            
        case .DatePicker:
            self.autocorrectionType = .no
            self.autocapitalizationType = .none
            self.shouldPreventAllActions = false
            self.setUpInputViewForPicker(arr: [])
            break
            
        case.none,
            .None_NOSPACE,
            .Characters_Number,
            .Characters_Number_NOSPACE,
            .Characters_SplCharacters ,
            .Characters_SplCharacters_NOSPACE,
            .Characters,
            .Characters_NOSPACE :
            self.keyboardType = UIKeyboardType.default
            self.autocapitalizationType = .words
            break
            
        case.Phone, .Number, .Number_Nozero :
            self.keyboardType = UIKeyboardType.phonePad
            break
        case .Number_Space:
            self.keyboardType = UIKeyboardType.namePhonePad
            break
        case.Float :
            self.keyboardType = UIKeyboardType.decimalPad
            break
        case.Email :
            self.keyboardType = UIKeyboardType.emailAddress
            self.autocapitalizationType = .none
            break
        case.Password :
            self.keyboardType = UIKeyboardType.default
            self.isSecureTextEntry = true
            self.shouldPreventAllActions = true
            break
            
        }
        
        self.setUpReturnKeyForTextField()
    }
    
    
    // MARK:- UIPickerView
    func setUpInputViewForPicker(arr:[String])
    {
        // UIPICKERVIEW
        if self.config.textFieldKeyboardType == .DatePicker {
            self.datePicker = UIDatePicker()
            let currentDate = Date()
            var dateComponents = DateComponents()
            let calendar = Calendar.init(identifier: .gregorian)
            dateComponents.year = -100
            let minDate = calendar.date(byAdding: dateComponents, to: currentDate)
//            dateComponents.year = -14
            //let maxDate = calendar.date(byAdding: dateComponents, to: currentDate)
            self.datePicker?.minimumDate = minDate
            self.datePicker?.maximumDate = currentDate
//            self.datePicker?.datePickerMode = .date
            self.datePicker?.datePickerMode = pickerMode
            self.inputView = self.datePicker
        }else {
            self.arrDataSource = arr
            self.pickerView = UIPickerView()
            self.pickerView!.dataSource = self
            self.pickerView!.delegate = self
            self.inputView = self.pickerView!
        }
        
        
        // TOOLBAR ITEMS
        let btnCancel: UIButton = UIButton()
        btnCancel.setTitle("Cancel", for: .normal)
        btnCancel.setTitleColor(UIColor.init(red: 0/255, green: 122/255, blue: 255/255, alpha: 1), for: .normal)
//        btnCancel.setTitleColor(UIColor.white, for: .normal)
        btnCancel.addTarget(self, action: #selector(self.btnCancelHandler(sender:)), for: .touchUpInside)
        btnCancel.sizeToFit()
        
        let btnDone: UIButton = UIButton()
        btnDone.setTitle("Done", for: .normal)
         btnDone.setTitleColor(UIColor.init(red: 0/255, green: 122/255, blue: 255/255, alpha: 1), for: .normal)
//        btnDone.setTitleColor(UIColor.white, for: .normal)
        btnDone.addTarget(self, action: #selector(self.btnDoneForPicker(sender:)), for: .touchUpInside)
        btnDone.sizeToFit()
        
        let barBtnCancel: UIBarButtonItem = UIBarButtonItem.init(customView: btnCancel)
        let barBtnDone: UIBarButtonItem = UIBarButtonItem.init(customView: btnDone)
        let barBtnFlexibleSpace: UIBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        // TOOLBAR
        let toolBar:UIToolbar = UIToolbar()
        toolBar.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 44)
        toolBar.barTintColor = UIColor(red: 210/255, green: 213/255, blue: 219/255, alpha: 1.0)
        toolBar.isTranslucent = true
        toolBar.items = [barBtnCancel,barBtnFlexibleSpace,barBtnDone]
        
        self.inputAccessoryView = toolBar
    }
    
    // MARK:- setting ReturnKey Type
    fileprivate func setUpReturnKeyForTextField()
    {
        if(self.keyboardType == .numberPad || self.keyboardType == .decimalPad || self.keyboardType == .phonePad)
        {
            
            // TOOLBAR
            let toolBar = UIToolbar()
            toolBar.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 44)
            toolBar.barTintColor = UIColor(red: 210/255, green: 213/255, blue: 219/255, alpha: 1.0)
            toolBar.isTranslucent = true
            
            // TOOLBAR ITEMS
            let buttonNext : UIButton = UIButton.init(frame:.zero)
            buttonNext.setTitle("Done", for: .normal)
//            buttonNext.setTitleColor(UIColor.white, for: .normal)
            buttonNext.setTitleColor(UIColor.init(red: 0/255, green: 122/255, blue: 255/255, alpha: 1), for: .normal)
            buttonNext.addTarget(self, action:#selector(CustomTextField.buttonNextPressed), for: .touchUpInside)
            buttonNext.sizeToFit()
            
            let buttonCancel : UIButton = UIButton.init(frame:.zero)
            buttonCancel.setTitle("Cancel", for: .normal)
            buttonCancel.setTitleColor(UIColor.init(red: 0/255, green: 122/255, blue: 255/255, alpha: 1), for: .normal)
//            buttonCancel.setTitleColor(UIColor.white, for: .normal)
            buttonCancel.addTarget(self, action: #selector(CustomTextField.buttonCancelPressed), for: .touchUpInside)
            buttonCancel.sizeToFit()
            
            let barButtonCancel = UIBarButtonItem(customView: buttonCancel)
            let barButtonNext = UIBarButtonItem(customView: buttonNext)
            let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
            
            toolBar.items = [barButtonCancel,flexibleSpace, barButtonNext]
            self.inputAccessoryView = toolBar
        }
    }
    
    // MARK: - BUTTON HANDLER
    
    
    /// Cancel Pressed
    @objc func buttonCancelPressed() {
        self.resignFirstResponder()
    }
    
    
    /// Next Pressed
    @objc func buttonNextPressed(){
        self.resignFirstResponder()
        //_ = self.delegate?.textFieldShouldReturn!(self)
    }
    
    
    /// Cancel Button handler
    ///
    /// - Parameter sender: UIButton
    @objc func btnCancelHandler(sender:UIButton) {
        if((self.blockCallFor_CancelButtonClicked) != nil){
            self.blockCallFor_CancelButtonClicked!(self)
        }
        self.resignFirstResponder()
    }
    
    
    /// Done Button handler
    ///
    /// - Parameter sender: UIButton
    @objc func btnDoneForPicker(sender:UIButton) {
        
        if self.config.textFieldKeyboardType == .DatePicker {
            self.selectedDateValue = (self.datePicker?.date)!
            self.text = (self.datePicker?.date)!.app_stringFromDate(formate: dateFormate!)
        }else {
            guard self.arrDataSource.count > 0 else {
                self.resignFirstResponder()
                return
            }
            self.selectedPickerValue = self.arrDataSource[(self.pickerView?.selectedRow(inComponent: 0))!]
            self.text = "\(self.selectedPickerValue!)"
        }
        
        if((self.blockCallFor_DoneButtonClicked) != nil){
            self.blockCallFor_DoneButtonClicked!(self)
        }
        self.resignFirstResponder()
    }
    
    
    
    // MARK: - PICKERVIEW DELEGATE
    
    open func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    open func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.arrDataSource.count
    }
    
    @objc public func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        
        let arrString = NSMutableAttributedString(string: "\(self.arrDataSource[row])")
        return arrString
    }
    
    public func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        guard arrDataSource.count > 0 else {
            return
        }
        // Set value on textField
        self.text = arrDataSource[row] as? String
        self.selectedPickerValue = arrDataSource[row]
        if(self.blockCallFor_PickerValueChanged != nil){
            self.blockCallFor_PickerValueChanged!(self)
        }
    }
    
    
    /**
     * TextField config
     */
    public struct Config {
        
        
        /// Textfield Bottom line normal color.
        public var  bottomLineNormalColor           : UIColor? = UIColor.darkGray
        
        
        /// Textfield Bottom line Editing mode color.
        public var bottomLineEditingColor           : UIColor? =  UIColor.darkGray
        
        
        /// Textfield Bottom line Editing mode color.
        public var floatingLabelEditingColor        : UIColor? =  UIColor.darkGray
        
        
        /// Textfield placeholderColor.
        public var placeholderColor                 : UIColor? = UIColor.darkGray
        
        /// Textfield TextColor
        public var textColor                        : UIColor? = UIColor.black
        
        /// For TextField max length.
        public var maxLength                        : Int? = 256
        
        
        /// For TextField min length.
        public var minLength                        : Int? = 0
        
        
        /// Set TextField type.
        public var textFieldType                    : CustomTextFieldType = .none
        
        
        /// Set TextField keyboard type.
        public var textFieldKeyboardType            : CustomTextFieldKeyboardType   = .none
        
        
        public init(textMinLength minLength : Int = 0,
                    textMaxLength maxLengt : Int = 256,
                    textFieldType type : CustomTextFieldType = .none,
                    textFieldKeyboardType keyboardType : CustomTextFieldKeyboardType = .none,
                    appPlaceholderColor placeholderColor : UIColor = UIColor.darkGray,
                    appFloatingLabelEditingColor labelEditingColor : UIColor = UIColor.darkGray,
                    appBottomLineNormalColor lineNormalColor : UIColor = UIColor.darkGray,
                    appBottomLineEditingColor lineEditingColor : UIColor = UIColor.darkGray,
                    appTextColor textColor : UIColor = UIColor.black) {
            
            
            self.minLength = minLength
            self.maxLength = maxLengt
            self.textFieldType = type
            self.textFieldKeyboardType = keyboardType
            self.placeholderColor = placeholderColor
            self.floatingLabelEditingColor = labelEditingColor
            self.bottomLineNormalColor = lineNormalColor
            self.bottomLineEditingColor = lineEditingColor
            self.textColor =  textColor
        }
        
    }
}

// MARK:-
private extension CustomTextField {
    
    // MARK: Functions
    func trimText()  {
        let trimmedString = self.text!.trimmingCharacters(in: CharacterSet.whitespaces)
        self.text = trimmedString
    }
    /*
    func checkMaxLength(_ range: NSRange,  maxLength : NSInteger, current string : String) -> Bool {
        
        if maxLength != 0 {
            if string != "" {
                if (self.text?.count)! < maxLength{
                    if range.location >= maxLength {
                        return false
                    }
                }else{
                    return false
                }
            }
            
            return true
        }
        return true
    }*/
    func checkMaxLength(_ range: NSRange,  maxLength : NSInteger, current string : String) -> Bool {
        
        if maxLength != 0 {
            if string != "" && string.count < 2
            {
                if (self.text?.count)! < maxLength{
                    if range.location >= maxLength {
                        return false
                    }
                }else{
                    return false
                }
            }
            else if string != "" && string.count > 1
            {
                let expLength = (self.text?.count)! + string.count
                
                if expLength-1 < maxLength
                {
                    if range.location >= maxLength {
                        return false
                    }
                }else
                {
                    return false
                }
            }
            
            return true
        }
        return true
    }
    
    // MARK: ALL VALIDATION
    func checkTextValidation(_ range: NSRange, replacementString string: String, txtType : CustomTextFieldKeyboardType = .none) -> Bool {
        
        switch txtType {
        case.none,
            .None_NOSPACE,
            .Characters_Number,
            .Characters_Number_NOSPACE,
            .Characters_SplCharacters ,
            .Characters_SplCharacters_NOSPACE,
            .Characters,
            .Characters_NOSPACE :
            
            return self.checkTextBlock(self, range: range, string: string, txtType: txtType)
            
        case.Phone, .Number, .Number_Nozero, .Number_Space , .Float :
            return self.checkNumberBlock(self, range: range, string: string, txtType: txtType)
            
        case.Email, .Password :
            return self.checkEmailAndPasswordBlock(self, range: range, string: string, txtType: txtType)
            
        default:
            return self.checkTextBlock(self, range: range, string: string, txtType: txtType)
        }
    }
    
    
    func checkTextBlock(_ textField: UITextField, range: NSRange, string: String, txtType : CustomTextFieldKeyboardType = .none) -> Bool  {
        
        var charactersToBlock : CharacterSet = CharacterSet()
        
        if txtType == .none{
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.none)
        }
        else if txtType == .None_NOSPACE {
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.None_NOSPACE)
        }
        else if txtType == .Characters_Number{
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Characters_Number)
        }
        else if txtType == .Characters_Number_NOSPACE {
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Characters_Number_NOSPACE)
        }
        else if txtType == .Characters_SplCharacters{
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Characters_SplCharacters)
        }
        else if txtType == .Characters_SplCharacters_NOSPACE {
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Characters_SplCharacters_NOSPACE)
        }
        else if txtType == .Characters {
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Characters)
        }
        else if txtType == .Characters_NOSPACE {
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Characters_NOSPACE)
        }
        
        
        
        if range.location == 0 {
            if string.hasPrefix(" ") {
                return false
            }
        }
        let length: Int = textField.text!.count
        if length > 0 {
            let originalString: String = textField.text!
            let index: Int = length
            var theCharacter : String = String()
            theCharacter = String(originalString[originalString.index(originalString.startIndex, offsetBy: index-1)])
            
            if theCharacter.hasPrefix(" ") && string.hasPrefix(" ") {
                return false
            }
        }
        if (string == "") {
            return true
        }
        
        if (string.rangeOfCharacter(from: charactersToBlock) != nil) {
            return true
        }
        else {
            return false
        }
        
    }
    
    
    func checkNumberBlock(_ textField: UITextField, range: NSRange, string: String, txtType : CustomTextFieldKeyboardType?) -> Bool  {
        
        var charactersToBlock : CharacterSet = CharacterSet()
        
        if txtType == .Phone{
            charactersToBlock = CharacterSet(charactersIn:CharacterSetType.Phone)
            if  (range.location == 0 &&  string == "0") {
                return false
            }
        }
        else if txtType == .Number {
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Number)
        }
        else if txtType == .Number_Space {
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Number_Space)
        }
        else if txtType == .Float {
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Float)
            
            if textField.text?.range(of:".") != nil && string == "." {
                return false
            }
            else{
                if textField.text?.range(of:".") != nil {
                    if let range = textField.text?.range(of:".") {
                        let Phone = String(describing: textField.text?.suffix(from: range.upperBound))
                        if ((Phone.count) > Int(1)) && string != ""{
                            return false
                        }
                    }
                }
            }
            
        }
        else if txtType == .Number_Nozero{
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Number_Nozero)
        }
        
        if range.location == 0 {
            if string.hasPrefix(" ") {
                return false
            }
        }
        if string == ""  {
            return true
        }
        
        if (string.rangeOfCharacter(from: charactersToBlock) != nil) {
            return true
        }
        else {
            return false
        }
        
    }
    
    func checkEmailAndPasswordBlock(_ textField: UITextField, range: NSRange, string: String, txtType : CustomTextFieldKeyboardType?) -> Bool  {
        
        var charactersToBlock : CharacterSet = CharacterSet()
        
        if txtType == .Email {
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Email)
        }
        else if  txtType == .Password{
            charactersToBlock = CharacterSet(charactersIn: CharacterSetType.Password)
        }
        
        if range.location == 0 {
            if string.hasPrefix(" ") {
                return false
            }
        }
        if (string == "") {
            return true
        }
        if (string.rangeOfCharacter(from: charactersToBlock) != nil) {
            return true
        }
        else {
            return false
        }
        
    }
    
    func checkEmoji(_ string : String) -> Bool {
        
        let emojiRanges = [
            0x1F601...0x1F64F,
            0x2702...0x27B0,
            0x1F680...0x1F6C0,
            0x1F170...0x1F251
        ]
        
        for range in emojiRanges {
            for i in range {
                let c = String(describing: UnicodeScalar(i))
                if (string == c) {
                    return false
                }
            }
        }
        return true
    }
    
}
extension UIView {
    var parentViewController: UIViewController? {
        var parentResponder: UIResponder? = self
        while parentResponder != nil {
            parentResponder = parentResponder!.next
            if let viewController = parentResponder as? UIViewController {
                return viewController
            }
        }
        return nil
    }
}


/// CharacterSetType for text validation
struct CharacterSetType {
    
    static var Email                                = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*(){}[]_-+*/~`.?<>"
    static var Password                             = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*(){}[]_-+*/~`.?<>"
    static var Phone                                = "0123456789"
    static var Number                               = "0123456789"
    static var Number_Space                         = "0123456789 "
    static var Number_Nozero                        = "123456789"
    static var Float                                = "0123456789."
    static var none                                 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*(){}[]_-+*/~`.?<> "
    static var None_NOSPACE                         = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*(){}[]_-+*/~`.?<>"
    static var Characters_Number                    = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 "
    static var Characters_Number_NOSPACE            = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    static var Characters_SplCharacters             = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*(){}[]_-+*/~`.?<> "
    static var Characters_SplCharacters_NOSPACE     = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*(){}[]_-+*/~`.?<>"
    static var Characters                           = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
    static var Characters_NOSPACE                   = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    
}


