//
//  Extension_Double.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

extension Double {
    
    var stringValue: String {
        if self == Double(Int(self)) {
            return "\(Int(self))"
        }
        return "\(self)"
    }
    var stringIgnoreIntValue: String {
        return "\(self)"
    }
    
    var stringValueWith2Fraction: String {
        return String.init(format: "%0.2f", self)
    }
}
