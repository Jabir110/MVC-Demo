//
//  CompanyListCollectionView.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class IncomeDetailsCollectionView: CustomCollectionView {
    
    //MARK:- PROPERTIES
    var arrIncomeDeatails: [IncomeDeatails] = []

    //MARK:- BLOCK PROPERTIES
    var blockCollectionViewDidSelectAtIndexPath: ((IncomeDeatails) -> Void)?

    //MARK:- AWAKE FROM NIB
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setupUI()
    }
    
    //MARK:- SETUP UI
    private func setupUI() {
        self.registerCell(IncomeDetailsCollectionViewCell.self)
        
        let flowLayout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .vertical
        self.collectionViewLayout = flowLayout
        self.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        self.allowsMultipleSelection = false
        self.isPagingEnabled = false
        self.backgroundColor = UIColor.clear
    }
    
    // MARK:- UICOLLECTIONVIEW DATASOURCE
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrIncomeDeatails.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell:IncomeDetailsCollectionViewCell = self.dequeueReusableCell(forIndexPath: indexPath)
        cell.updateDate(objIncomeDetails: arrIncomeDeatails[indexPath.row])
        return cell
    }
    
    //MARK:- COLLECTIONVIEW  FLOWLAYOUT DELEGATE
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 5.0, left: 5.0, bottom: 5.0, right: 5.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let cellWidth   = (self.frame.size.width/2) - 5.0
        let cellHeight  = cellWidth
        return CGSize(width: cellWidth , height: cellHeight)
    }
    
    //MARK:- COLLECTIONVIEW DELEGATE
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if self.blockCollectionViewDidSelectAtIndexPath != nil {
            self.blockCollectionViewDidSelectAtIndexPath!(arrIncomeDeatails[indexPath.row])
        }
    }
}
