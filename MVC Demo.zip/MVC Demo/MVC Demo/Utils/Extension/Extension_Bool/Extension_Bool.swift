//
//  Extension_Bool.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

extension Bool {
    var stringValue: String {
        return self ? "true" : "false"
    }
}
