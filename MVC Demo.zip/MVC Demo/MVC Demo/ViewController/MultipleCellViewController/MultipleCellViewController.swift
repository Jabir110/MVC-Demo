//
//  MultipleCellViewController.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class MultipleCellViewController: UIViewController {

    //MARK:- OUTLET
    @IBOutlet private weak var multipleCellTableView: MultipleCellTableView!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        self.callExampleList()
    }
    
    //MARK:- SETUP UI
    private func setupUI(){
        
        //NAVIGATION BAR
        self.title = "MVC Example"
        self.navigationController?.navigationBar.tintColor = UIColor.black
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage.init(named: "left_Arrow"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(btnBackActionHandler(_:)))

        //BLOCK REGISTER
        self.multipleCellTableView.blockTableViewDidSelectAtIndexPath = { (indexPath) in
            
            print("SELECTED INDEX: \(indexPath.row)")
            
            switch indexPath.row {
            case 0:
                let pushVC = CompanyListViewController.loadController(strStoryBoardName: StoryboardName.Main.rawValue)
                self.navigationController?.pushViewController(pushVC, animated: true)
                break
            case 1:
                let pushVC = IncomeDetailsViewController.loadController(strStoryBoardName: StoryboardName.Main.rawValue)
                self.navigationController?.pushViewController(pushVC, animated: true)
                break
            default:
                print("DEFAULT")
            }
        }
    }
    
    //MARK:- BUTTON ACTION
    @objc private func btnBackActionHandler(_ sender : AnyObject){
        self.popTo()
    }

}

//MARK:- CUSTOM DATA LOAD
extension MultipleCellViewController {

    private func callExampleList() {
  
        var arrList:[String] = []
        arrList.append("Microsoft")
        arrList.append("IBM")
        arrList.append("Oracle")
        arrList.append("Accenture")
        arrList.append("TCS")

        self.multipleCellTableView.arrList = arrList
        self.multipleCellTableView.reloadData()
    }
}
