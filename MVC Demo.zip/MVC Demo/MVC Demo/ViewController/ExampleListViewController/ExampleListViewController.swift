//
//  DemoViewController.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class ExampleListViewController: UIViewController {

    //MARK:- OUTLET
    @IBOutlet private weak var exampleListTableView: ExampleListTableView!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        self.callExampleList()
    }
    
    //MARK:- SETUP UI
    private func setupUI(){
        
        //NAVIGATION BAR
        self.title = "MVC Example"

        //BLOCK REGISTER
        self.exampleListTableView.blockTableViewDidSelectAtIndexPath = { (indexPath) in
            
            print("SELECTED INDEX: \(indexPath.row)")
            
            switch indexPath.row {
            case 0:
                let pushVC = CompanyListViewController.loadController(strStoryBoardName: StoryboardName.Main.rawValue)
                self.navigationController?.pushViewController(pushVC, animated: true)
                break
            case 1:
                let pushVC = IncomeDetailsViewController.loadController(strStoryBoardName: StoryboardName.Main.rawValue)
                self.navigationController?.pushViewController(pushVC, animated: true)
                break
            case 2:
                let pushVC = MultipleCellViewController.loadController(strStoryBoardName: StoryboardName.Main.rawValue)
                self.navigationController?.pushViewController(pushVC, animated: true)
                break
            default:
                print("DEFAULT")
            }
        }
    }
}

//MARK:- CUSTOM DATA LOAD
extension ExampleListViewController {

    private func callExampleList() {
  
        var arrList:[String] = []
        arrList.append("TableView")
        arrList.append("CollectionView")
        arrList.append("Multiple TableViewCell")

        self.exampleListTableView.arrExampleList = arrList
        self.exampleListTableView.reloadData()
    }
}
