//
//  CustomCollectionViewCell.swift
//
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//


import UIKit

open class CustomCollectionViewCell: UICollectionViewCell {
    
}
