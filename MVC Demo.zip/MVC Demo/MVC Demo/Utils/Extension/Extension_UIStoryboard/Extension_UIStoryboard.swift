//
//  UIStoryboardExtension.swift
//
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

public extension UIStoryboard {
    
    
    /// Set Storyboard
    ///
    /// - Returns: UIStoryboard
    class func mainStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }
}
