//
//  SigupFormViewController.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class SigupFormViewController: UIViewController {

    //MARK:- OUTLET
    @IBOutlet private weak var txtUserName : CustomTextField!
    @IBOutlet private weak var txtFirstName : CustomTextField!
    @IBOutlet private weak var txtLastName : CustomTextField!
    @IBOutlet private weak var txtEmailAddress : CustomTextField!
    @IBOutlet private weak var txtMobileNumber : CustomTextField!
    @IBOutlet private weak var switchGender : UISwitch!
    
    //MARK:- VIEW LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        self.callExampleList()
    }
    
    //MARK:- SETUP UI
    private func setupUI(){
        
        //NAVIGATION BAR
        self.title = "MVC Example"

        //BLOCK REGISTER
        txtUserName.blockTextFieldDidBeginEditing = { (textField) in
            print(textField.text!)
        }
    }
}

//MARK:- CUSTOM DATA LOAD
extension SigupFormViewController {

    func callExampleList() {
  
        var arrList:[String] = []
        arrList.append("Microsoft")
        arrList.append("IBM")
        arrList.append("Oracle")
        arrList.append("Accenture")
        arrList.append("TCS")
    }
}
