//
//  CompanyList.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation
import UIKit

struct CompanyModelKeys {
    
    static let kTicker = "Ticker"
    static let kPrice = "Price"
    static let kChanges = "Changes"
    static let kChangesPerc = "ChangesPerc"
    static let kCompanyName = "companyName"
}

class Company: NSObject
{
    var ticker: String? = ""
    var price: String? = ""
    var changes: Double = -1
    var changesPerc: String? = ""
    var companyName: String? = ""
    
    override init() {
        super.init()
    }
    
    convenience init(withDetails dict: NSDictionary) {
        self.init()
        
        self.ticker = dict.object_forKeyWithValidationForClass_String(aKey: CompanyModelKeys.kTicker)
        self.price = dict.object_forKeyWithValidationForClass_String(aKey: CompanyModelKeys.kPrice)
        self.changes = dict[CompanyModelKeys.kChanges] as? Double ?? self.changes
        self.changesPerc = dict.object_forKeyWithValidationForClass_String(aKey: CompanyModelKeys.kChangesPerc)
        self.companyName = dict.object_forKeyWithValidationForClass_String(aKey: CompanyModelKeys.kCompanyName)

    }
}
