//
//  ApiConstant.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation

struct APIConstant {

    static let baseURL = "https://financialmodelingprep.com/api/" // Local Server
}

//MARK:- _______________ USERDEFAULT KEYS  _______________
struct UserDefaultsKeys {

}

//MARK:-
struct ApiName {
    static let activesApiName           = "stock/actives?datatype=json"
    static let incomeDeatailsApiName    = "financials/income-statement/{KEY}?datatype=json"
}

//MARK:-
struct ApiURL {
    static let activesApiURL            = APIConstant.baseURL + ApiName.activesApiName
    static let incomeDeatailsApiURL     = APIConstant.baseURL + ApiName.incomeDeatailsApiName
}

//MARK:-
struct HeaderKeys {
    static var contentType = "Content-Type"
    static var Accept = "Accept"
}

//MARK:-
struct RequestKeys {

}

//MARK:-
struct ResponseKeys{
    static var messageKey = "Message"
    static var userIdKey = "userId"
    static var imageURLKey = "imageURL"
}

//Image Upload Key
enum EnumUploadImagesType : Int {
    case documentsKey
    
    var key: String {
        switch self {
        case .documentsKey:
            return "documents"
        }
    }
}
