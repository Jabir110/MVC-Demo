//
//  MultipleCellCableView.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

enum MultipleTableViewCellType: Int, CaseIterable {
    case header
    case body
    case footer
}

class MultipleCellTableView: CustomTableView {
    
    // MARK:- PROPERTIES
    var arrList: [String] = []
    
    //MARK:- BLOCK PROPERTIES
    var blockTableViewDidSelectAtIndexPath: IndexPathTableViewDidSelectBlock = nil

    // MARK:- INIT METHODS
    override func awakeFromNib() {
        super.awakeFromNib()
        self.contentInset = UIEdgeInsets(top: 5.0, left: 0.0, bottom: 40.0, right: 0.0)
       
        // CONFIGURATION
        self.backgroundColor = UIColor.white
        self.estimatedRowHeight = 50.0
        self.rowHeight = UITableView.automaticDimension
        self.isPullToRefreshEnabled = false
    }
    
    // MARK:- TABLEVIEW DATASOURCE & DELEGATE METHODS
    override func numberOfSections(in tableView: UITableView) -> Int {
        return MultipleTableViewCellType.allCases.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == MultipleTableViewCellType.body.rawValue {
            return (arrList.count)
        }
        return 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == MultipleTableViewCellType.header.rawValue {
            let cell: HeaderTableViewCell = self.dequeueReusableCell()
            cell.updateDate(title: "IT Company")
            return cell
        }
        else if indexPath.section == MultipleTableViewCellType.body.rawValue {
            let cell: BodyTableViewCell = self.dequeueReusableCell()
            cell.updateDate(title: arrList[indexPath.row])
            return cell
        }
        else if indexPath.section == MultipleTableViewCellType.footer.rawValue {
            let cell: FooterTableViewCell = self.dequeueReusableCell()
            cell.updateDate(title: "Footer")
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.blockTableViewDidSelectAtIndexPath != nil {
            self.blockTableViewDidSelectAtIndexPath!(indexPath)
        }
    }
}
