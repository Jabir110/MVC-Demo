//
//  FileManager+Extension.swift
//  DealMeanUser
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation

extension FileManager {
    static let strtemporarySavedPhotos = "TemporarySavedPhotos"
    
    //For used temporaray capturing View
    var temporarySavedPhotos : String {
        return self.createDirectory(FileManager.strtemporarySavedPhotos)
    }
    
    
    func createDirectory(_ name : String) -> String {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dataPath = documentsDirectory.appendingPathComponent(name)
        
        var isDir : ObjCBool = false
        if self.fileExists(atPath: dataPath.path, isDirectory: &isDir) {
            if isDir.boolValue {
                //file exists and is a directory
                //print("temporary video directory already exists.")
            }
        } else {
            do {
                try FileManager.default.createDirectory(atPath: dataPath.path, withIntermediateDirectories: false, attributes: nil)
            } catch let error as NSError {
                print(error.localizedDescription)
            }
            
        }
        
        return dataPath.path
    }
    
    func removeDirectory(_ path: String) {
        do {
            try self.removeItem(atPath: path)
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func removeFile(_ path : String) {
        if self.fileExists(atPath: path) {
            do {
                try self.removeItem(atPath: path)
            } catch {
                print(error.localizedDescription)
            }
        }
    }
}

