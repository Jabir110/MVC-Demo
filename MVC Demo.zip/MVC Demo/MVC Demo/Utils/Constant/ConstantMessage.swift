//
//  ConstantMessage.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation

// MARK: - MESSAGES
struct  Messages {
    
    static let appName = Constants.AppName
    static let internetConnectionAlert = "Internet connection is not available. Please check your internet connection and try again."
}
