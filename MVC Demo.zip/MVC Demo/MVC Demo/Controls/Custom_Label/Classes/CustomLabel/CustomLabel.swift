//
//  CustomLabel.swift
//  Expense
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

//MARK:- REGULAR LABEL
class CustomLabel: UILabel {
    
    //MARK:- INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit() {
        self.font = UIFont.appRegularFont(WithSize: self.font!.pointSize, shouldResize: true)
    }
}

//MARK:- MEDIUM LABEL
class CustomLabelMedium: UILabel {
    
    //MARK:- INIT
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        commonInit()
    }
    
    private func commonInit() {
        self.font = UIFont.appMediumFont(WithSize: self.font!.pointSize, shouldResize: true)
    }
}
