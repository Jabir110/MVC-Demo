//
//  FooterTableViewCell.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class FooterTableViewCell: UITableViewCell {

    // MARK:- OUTLET
    @IBOutlet private weak var lblTitle: CustomLabel!
    @IBOutlet private weak var viewMain: UIView!

    // MARK:- INIT METHODS
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    // MARK:- SETUP UI & DATA
    private func setupUI() {
        viewMain.layer.cornerRadius = 0.0
    }
    
    func updateDate(title: String) {
        lblTitle.text = title
    }
}
