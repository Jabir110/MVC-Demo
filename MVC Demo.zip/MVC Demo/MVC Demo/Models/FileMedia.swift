//
//  FileMedia.swift
//  MVC Demo
//
//  Created by Apple Inc.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import Foundation
import Photos

enum EnumMediaType: Int, CaseIterable
{
    case image
    case video
    case file
    case audio
    case none
    
    var titleName: String
    {
        switch self
        {
        case .image:
            return "image"
        case .video:
            return "video"
        case .audio:
            return "audio"
        case .file:
            return "file"
        case .none:
            return "None"
        }
    }
}

enum EnumMediaOptionFrom: Int, CaseIterable
{
    case camera
    case library
    case none
    
    var titleName: String
    {
        switch self
        {
        case .camera:
            return "Camera"
        case .library:
            return "Library"
        case .none:
            return "None"
        }
    }
}

public class FileMedia: NSObject
{
    // MARK: - PROPERTIES -
    var id :String = ""
    var localUrl:String = ""
    var asset:PHAsset?
    var mediaType:EnumMediaType = EnumMediaType.none
    var image:UIImage? = nil
    var mediaName:String = ""
    var mineType:String = ""
    var selectedFrom:EnumMediaOptionFrom = EnumMediaOptionFrom.none
    
    var localFileName:String = ""
    var localDocumentUrl:String = ""
    
    var getLocalUrl: URL {
        return URL(fileURLWithPath: localDocumentUrl)
    }
    
    //MARK:- INIT -
    override init() {
        super.init()
    }
    
    init(withPHAsset object:PHAsset, mediaType type:EnumMediaType, selectedForm from:EnumMediaOptionFrom) {
        super.init()
        self.asset = object
        self.mediaType = type
        self.localUrl = object.localIdentifier
        self.selectedFrom = from
    }
    
    init(withPickedImage pickedImage:UIImage, mediaType type:EnumMediaType, selectedForm from:EnumMediaOptionFrom) {
        super.init()
        self.mediaType = type
        self.localUrl = pickedImage.saveImage(directory: FileManager.strtemporarySavedPhotos)
        self.image = pickedImage
        self.selectedFrom = from
    }
    
    init(dict:NSDictionary)
    {
        self.id = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.userIdKey)
        self.localUrl = dict.object_forKeyWithValidationForClass_String(aKey: ResponseKeys.imageURLKey)
    }
    
    class func loadMediaModelArray(forArray arr:NSArray) -> [FileMedia]
    {
        var arrayTemp:[FileMedia] = [FileMedia]()
        
        for obj in arr
        {
            arrayTemp.append(FileMedia(dict: obj as! NSDictionary))
        }
        
        return arrayTemp
    }
}

